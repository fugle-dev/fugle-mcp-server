# fubon-neo (Node.js)

富邦新一代 API 的 Node.js 套件，為您的程式交易提供完善的交易與行情 API，
滿足量化與自動化交易的需求。

## 安裝

```sh
npm install fubon-neo
```

各平台的預編譯原生二進位檔已內含於套件中，載入時會依當前平台自動選用，無需額外下載或編譯。

## 快速開始

```js
import { FubonSDK } from 'fubon-neo';

const sdk = new FubonSDK();
// const accounts = sdk.login("<身分證字號>", "<密碼>", "<憑證路徑.pfx>", "<憑證密碼>");
```

## 支援平台

| OS | 架構 |
|----|------|
| Windows | x64 |
| macOS | x64、arm64 |
| Linux (glibc) | x64、arm64 |

## 文件

完整的交易、行情與期貨 API 說明、範例程式與事前準備事項，請參考官方文件：

**https://www.fbs.com.tw/TradeAPI/**
