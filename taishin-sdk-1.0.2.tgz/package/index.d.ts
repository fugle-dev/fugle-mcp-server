export * from './core.js';
import { CoreSdk, Account } from './core.js';
import { RestClient, WebSocketClient } from '@fugle/marketdata';
import { Mode } from './adapter.js';
export { Mode };
declare class TaishinSDK extends CoreSdk {
    marketdata?: {
        webSocketClient: WebSocketClient;
        restClient: RestClient;
    };
    /**
     * constructor of TaishinSDK
     * @param url The API URL
     */
    constructor(url?: string | null);
    /**
     * Initial market data and get authorised
     * @param account - Account to use for realtime connection
     * @param mode - Speed or Normal mode (defaults to Normal)
     */
    initRealtime(account: Account, mode?: Mode): void;
}
export { TaishinSDK };
