// Re-export all types and values from core.js
export * from './core.js';

// Import what we need for TaishinSDK implementation
import { CoreSdk, FugleRealtime, Account } from './core.js';
import { RestClient, WebSocketClient } from '@fugle/marketdata';
import { Mode, buildWebSocketClient, buildRestClient } from './adapter.js';

// Re-export Mode for external use
export { Mode };

class TaishinSDK extends CoreSdk {
  marketdata?: {
    webSocketClient: WebSocketClient;
    restClient: RestClient;
  };

  /**
   * constructor of TaishinSDK
   * @param url The API URL
   */
  constructor(url?: string | null) {
    super(url as any);
    (global as any).__taishin_sdk_ref__ = this;
  }

  /**
   * Initial market data and get authorised
   * @param account - Account to use for realtime connection
   * @param mode - Speed or Normal mode (defaults to Normal)
   */
  initRealtime(account: Account, mode = Mode.Normal) {
    const realtimeResult = super.getRealtimeToken(account);
    const fugleRealtime = new FugleRealtime();

    this.marketdata = {
      webSocketClient: buildWebSocketClient(mode, realtimeResult.realtimeToken, fugleRealtime),
      restClient: buildRestClient(realtimeResult.realtimeToken, fugleRealtime),
    };
  }
}

// Export our custom SDK class
export { TaishinSDK };
