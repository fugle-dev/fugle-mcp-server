"use strict";
/**
 * Adapter layer for converting Mode enum to WebSocket configuration
 * This preserves backward compatibility while using the @fugle/marketdata package
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.Mode = void 0;
exports.buildWebSocketConfig = buildWebSocketConfig;
exports.buildRestConfig = buildRestConfig;
exports.buildWebSocketClient = buildWebSocketClient;
exports.buildRestClient = buildRestClient;
const marketdata_1 = require("@fugle/marketdata");
/**
 * Mode enum for backward compatibility
 * Maps to different WebSocket endpoint URLs
 */
var Mode;
(function (Mode) {
    Mode["Speed"] = "speed";
    Mode["Normal"] = "normal";
})(Mode || (exports.Mode = Mode = {}));
/**
 * Build WebSocket configuration from Mode enum
 *
 * @param mode - Speed or Normal mode
 * @param bearerToken - Bearer authentication token
 * @param fugleRealtime - Rust FugleRealtime class instance for URL retrieval
 * @returns Configuration object for WebSocket client
 */
function buildWebSocketConfig(mode, bearerToken, fugleRealtime) {
    const baseUrl = mode === Mode.Speed
        ? fugleRealtime.realtimeWsSpeedUrl
        : fugleRealtime.realtimeWsNormalUrl;
    return {
        baseUrl: `${baseUrl}/v1.0`,
        bearerToken,
        healthCheck: {
            enabled: true,
            pingInterval: 30000,
            maxMissedPongs: 2
        }
    };
}
/**
 * Build REST client configuration
 *
 * @param bearerToken - Bearer authentication token
 * @param fugleRealtime - Rust FugleRealtime class instance for URL retrieval
 * @returns Configuration object for REST client
 */
function buildRestConfig(bearerToken, fugleRealtime) {
    return {
        baseUrl: `${fugleRealtime.realtimeRestUrl}/v1.0`,
        bearerToken
    };
}
/**
 * Wrapper for WebSocketStockClient with Speed mode channel validation
 */
class WebSocketStockClientWrapper {
    constructor(client, mode) {
        this._client = client;
        this._mode = mode;
    }
    subscribe(params) {
        if (this._mode === Mode.Speed) {
            if (params.channel === 'aggregates' || params.channel === 'candles') {
                throw new Error(`Speed mode doesn't support ${params.channel} channel`);
            }
        }
        return this._client.subscribe(params);
    }
    unsubscribe(params) { return this._client.unsubscribe(params); }
    disconnect() { return this._client.disconnect(); }
    connect() { return this._client.connect(); }
    ping(params) { return this._client.ping(params); }
    subscriptions() { return this._client.subscriptions(); }
    on(event, listener) { return this._client.on(event, listener); }
    once(event, listener) { return this._client.once(event, listener); }
    off(event, listener) { return this._client.off(event, listener); }
    emit(event, ...args) { return this._client.emit(event, ...args); }
}
/**
 * Wrapper for WebSocketFutOptClient with Speed mode channel validation
 */
class WebSocketFutOptClientWrapper {
    constructor(client, mode) {
        this._client = client;
        this._mode = mode;
    }
    subscribe(params) {
        if (this._mode === Mode.Speed) {
            if (params.channel === 'aggregates' || params.channel === 'candles') {
                throw new Error(`Speed mode doesn't support ${params.channel} channel`);
            }
        }
        return this._client.subscribe(params);
    }
    unsubscribe(params) { return this._client.unsubscribe(params); }
    disconnect() { return this._client.disconnect(); }
    connect() { return this._client.connect(); }
    ping(params) { return this._client.ping(params); }
    subscriptions() { return this._client.subscriptions(); }
    on(event, listener) { return this._client.on(event, listener); }
    once(event, listener) { return this._client.once(event, listener); }
    off(event, listener) { return this._client.off(event, listener); }
    emit(event, ...args) { return this._client.emit(event, ...args); }
}
/**
 * Build WebSocket client with Mode-based configuration and channel validation
 *
 * @param mode - Speed or Normal mode
 * @param bearerToken - Bearer authentication token
 * @param fugleRealtime - Rust FugleRealtime class instance for URL retrieval
 * @returns WebSocketClient instance with wrapped stock/futopt clients
 */
function buildWebSocketClient(mode, bearerToken, fugleRealtime) {
    const config = buildWebSocketConfig(mode, bearerToken, fugleRealtime);
    const client = new marketdata_1.WebSocketClient(config);
    let cachedStockWrapper = null;
    let cachedFutOptWrapper = null;
    return new Proxy(client, {
        get(target, prop, receiver) {
            if (prop === 'stock') {
                if (!cachedStockWrapper) {
                    cachedStockWrapper = new WebSocketStockClientWrapper(target.stock, mode);
                }
                return cachedStockWrapper;
            }
            if (prop === 'futopt') {
                if (!cachedFutOptWrapper) {
                    cachedFutOptWrapper = new WebSocketFutOptClientWrapper(target.futopt, mode);
                }
                return cachedFutOptWrapper;
            }
            const value = Reflect.get(target, prop, receiver);
            if (typeof value === 'function') {
                return value.bind(target);
            }
            return value;
        }
    });
}
/**
 * Build REST client with configuration
 *
 * @param bearerToken - Bearer authentication token
 * @param fugleRealtime - Rust FugleRealtime class instance for URL retrieval
 * @returns RestClient instance
 */
function buildRestClient(bearerToken, fugleRealtime) {
    const config = buildRestConfig(bearerToken, fugleRealtime);
    return new marketdata_1.RestClient(config);
}
