### 事前準備


1. 準備環境 ex: rust + node.js (>= 18.0.0)


2. 安裝 dependencied

``` sh
yarn
```

### 開發

``` sh
npm run build:debug
```

napi-rs 會自動把 build 出來的檔案放到資料夾內 xxxxxxx.darwin-arm64.node


## build 

只要在這個平台使用的話

``` sh
npm run build
```


## cross build

可以參考 repo 下的 Dockerfile 裡面把環境準備好了

以下是 run 在 docker 裡的 sh 


``` sh
 docker run -it --rm --platform=linux/amd64 -v $(pwd):/root/app taishin:x86
```


#### js-win:

``` sh
CARGO=cargo-xwin yarn build --target=x86_64-pc-windows-msvc
```


#### js-mac-intel:
	
```sh
CC=o64-clang CXX=o64-clang++ yarn build --target=x86_64-apple-darwin
```

#### js-mac-arm

``` sh
CC=oa64-clang CXX=oa64-clang++ yarn build --target=aarch64-apple-darwin
```


#### js-linux:

``` sh
yarn build

```







