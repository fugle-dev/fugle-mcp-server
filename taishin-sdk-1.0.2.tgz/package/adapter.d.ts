/**
 * Adapter layer for converting Mode enum to WebSocket configuration
 * This preserves backward compatibility while using the @fugle/marketdata package
 */
import { WebSocketClient, RestClient } from '@fugle/marketdata';
import type { WebSocketClientOptions } from '@fugle/marketdata';
/**
 * Mode enum for backward compatibility
 * Maps to different WebSocket endpoint URLs
 */
export declare enum Mode {
    Speed = "speed",
    Normal = "normal"
}
/**
 * Build WebSocket configuration from Mode enum
 *
 * @param mode - Speed or Normal mode
 * @param bearerToken - Bearer authentication token
 * @param fugleRealtime - Rust FugleRealtime class instance for URL retrieval
 * @returns Configuration object for WebSocket client
 */
export declare function buildWebSocketConfig(mode: Mode, bearerToken: string, fugleRealtime: any): Partial<WebSocketClientOptions>;
/**
 * Build REST client configuration
 *
 * @param bearerToken - Bearer authentication token
 * @param fugleRealtime - Rust FugleRealtime class instance for URL retrieval
 * @returns Configuration object for REST client
 */
export declare function buildRestConfig(bearerToken: string, fugleRealtime: any): {
    baseUrl: string;
    bearerToken: string;
};
/**
 * Build WebSocket client with Mode-based configuration and channel validation
 *
 * @param mode - Speed or Normal mode
 * @param bearerToken - Bearer authentication token
 * @param fugleRealtime - Rust FugleRealtime class instance for URL retrieval
 * @returns WebSocketClient instance with wrapped stock/futopt clients
 */
export declare function buildWebSocketClient(mode: Mode, bearerToken: string, fugleRealtime: any): WebSocketClient;
/**
 * Build REST client with configuration
 *
 * @param bearerToken - Bearer authentication token
 * @param fugleRealtime - Rust FugleRealtime class instance for URL retrieval
 * @returns RestClient instance
 */
export declare function buildRestClient(bearerToken: string, fugleRealtime: any): RestClient;
