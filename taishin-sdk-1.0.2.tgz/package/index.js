"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TaishinSDK = exports.Mode = void 0;
// Re-export all types and values from core.js
__exportStar(require("./core.js"), exports);
// Import what we need for TaishinSDK implementation
const core_js_1 = require("./core.js");
const adapter_js_1 = require("./adapter.js");
Object.defineProperty(exports, "Mode", { enumerable: true, get: function () { return adapter_js_1.Mode; } });
class TaishinSDK extends core_js_1.CoreSdk {
    /**
     * constructor of TaishinSDK
     * @param url The API URL
     */
    constructor(url) {
        super(url);
        global.__taishin_sdk_ref__ = this;
    }
    /**
     * Initial market data and get authorised
     * @param account - Account to use for realtime connection
     * @param mode - Speed or Normal mode (defaults to Normal)
     */
    initRealtime(account, mode = adapter_js_1.Mode.Normal) {
        const realtimeResult = super.getRealtimeToken(account);
        const fugleRealtime = new core_js_1.FugleRealtime();
        this.marketdata = {
            webSocketClient: (0, adapter_js_1.buildWebSocketClient)(mode, realtimeResult.realtimeToken, fugleRealtime),
            restClient: (0, adapter_js_1.buildRestClient)(realtimeResult.realtimeToken, fugleRealtime),
        };
    }
}
exports.TaishinSDK = TaishinSDK;
