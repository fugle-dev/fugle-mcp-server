/**
 * Adapter layer for converting Mode enum to WebSocket configuration
 * This preserves backward compatibility while using the @fugle/marketdata package
 */

import { WebSocketClient, RestClient } from '@fugle/marketdata';
import type { HealthCheckConfig, WebSocketClientOptions } from '@fugle/marketdata';

/**
 * Mode enum for backward compatibility
 * Maps to different WebSocket endpoint URLs
 */
export enum Mode {
  Speed = 'speed',
  Normal = 'normal'
}

/**
 * Build WebSocket configuration from Mode enum
 *
 * @param mode - Speed or Normal mode
 * @param bearerToken - Bearer authentication token
 * @param fugleRealtime - Rust FugleRealtime class instance for URL retrieval
 * @returns Configuration object for WebSocket client
 */
export function buildWebSocketConfig(
  mode: Mode,
  bearerToken: string,
  fugleRealtime: any
): Partial<WebSocketClientOptions> {
  const baseUrl = mode === Mode.Speed
    ? fugleRealtime.realtimeWsSpeedUrl
    : fugleRealtime.realtimeWsNormalUrl;

  return {
    baseUrl: `${baseUrl}/v1.0`,
    bearerToken,
    healthCheck: {
      enabled: true,
      pingInterval: 30000,
      maxMissedPongs: 2
    } as HealthCheckConfig
  } as any;
}

/**
 * Build REST client configuration
 *
 * @param bearerToken - Bearer authentication token
 * @param fugleRealtime - Rust FugleRealtime class instance for URL retrieval
 * @returns Configuration object for REST client
 */
export function buildRestConfig(bearerToken: string, fugleRealtime: any) {
  return {
    baseUrl: `${fugleRealtime.realtimeRestUrl}/v1.0`,
    bearerToken
  };
}

/**
 * Wrapper for WebSocketStockClient with Speed mode channel validation
 */
class WebSocketStockClientWrapper {
  private _client: any;
  private _mode: Mode;

  constructor(client: any, mode: Mode) {
    this._client = client;
    this._mode = mode;
  }

  subscribe(params: { channel: string; [key: string]: any }) {
    if (this._mode === Mode.Speed) {
      if (params.channel === 'aggregates' || params.channel === 'candles') {
        throw new Error(`Speed mode doesn't support ${params.channel} channel`);
      }
    }
    return this._client.subscribe(params);
  }

  unsubscribe(params: any) { return this._client.unsubscribe(params); }
  disconnect() { return this._client.disconnect(); }
  connect() { return this._client.connect(); }
  ping(params: any) { return this._client.ping(params); }
  subscriptions() { return this._client.subscriptions(); }

  on(event: string, listener: Function) { return this._client.on(event, listener); }
  once(event: string, listener: Function) { return this._client.once(event, listener); }
  off(event: string, listener: Function) { return this._client.off(event, listener); }
  emit(event: string, ...args: any[]) { return this._client.emit(event, ...args); }
}

/**
 * Wrapper for WebSocketFutOptClient with Speed mode channel validation
 */
class WebSocketFutOptClientWrapper {
  private _client: any;
  private _mode: Mode;

  constructor(client: any, mode: Mode) {
    this._client = client;
    this._mode = mode;
  }

  subscribe(params: { channel: string; [key: string]: any }) {
    if (this._mode === Mode.Speed) {
      if (params.channel === 'aggregates' || params.channel === 'candles') {
        throw new Error(`Speed mode doesn't support ${params.channel} channel`);
      }
    }
    return this._client.subscribe(params);
  }

  unsubscribe(params: any) { return this._client.unsubscribe(params); }
  disconnect() { return this._client.disconnect(); }
  connect() { return this._client.connect(); }
  ping(params: any) { return this._client.ping(params); }
  subscriptions() { return this._client.subscriptions(); }

  on(event: string, listener: Function) { return this._client.on(event, listener); }
  once(event: string, listener: Function) { return this._client.once(event, listener); }
  off(event: string, listener: Function) { return this._client.off(event, listener); }
  emit(event: string, ...args: any[]) { return this._client.emit(event, ...args); }
}

/**
 * Build WebSocket client with Mode-based configuration and channel validation
 *
 * @param mode - Speed or Normal mode
 * @param bearerToken - Bearer authentication token
 * @param fugleRealtime - Rust FugleRealtime class instance for URL retrieval
 * @returns WebSocketClient instance with wrapped stock/futopt clients
 */
export function buildWebSocketClient(
  mode: Mode,
  bearerToken: string,
  fugleRealtime: any
): WebSocketClient {
  const config = buildWebSocketConfig(mode, bearerToken, fugleRealtime);
  const client = new WebSocketClient(config as any);

  let cachedStockWrapper: WebSocketStockClientWrapper | null = null;
  let cachedFutOptWrapper: WebSocketFutOptClientWrapper | null = null;

  return new Proxy(client, {
    get(target, prop, receiver) {
      if (prop === 'stock') {
        if (!cachedStockWrapper) {
          cachedStockWrapper = new WebSocketStockClientWrapper(target.stock, mode);
        }
        return cachedStockWrapper;
      }

      if (prop === 'futopt') {
        if (!cachedFutOptWrapper) {
          cachedFutOptWrapper = new WebSocketFutOptClientWrapper(target.futopt, mode);
        }
        return cachedFutOptWrapper;
      }

      const value = Reflect.get(target, prop, receiver);
      if (typeof value === 'function') {
        return value.bind(target);
      }
      return value;
    }
  }) as WebSocketClient;
}

/**
 * Build REST client with configuration
 *
 * @param bearerToken - Bearer authentication token
 * @param fugleRealtime - Rust FugleRealtime class instance for URL retrieval
 * @returns RestClient instance
 */
export function buildRestClient(bearerToken: string, fugleRealtime: any): RestClient {
  const config = buildRestConfig(bearerToken, fugleRealtime);
  return new RestClient(config);
}
